## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7, fig.height = 5
)

require(tidyverse)

if (Sys.info()[1] == "Windows") {
  windowsFonts(`MS P明朝` = windowsFont("ＭＳ Ｐ明朝"),
               `MS ゴシック` = windowsFont("ＭＳ ゴシック"))
  base_family = c("MS P明朝")
  family = c("MS ゴシック")
} else if (Sys.info()[1] == "Linux") {
  base_family = c("Noto Serif CJK JP")
  family = c("Noto Mono")
} else {  # macOS
  base_family = c("HiraKakuPro-W3")
  family = c("Osaka")
}

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     labels = row.names(mtcars),
                     base_family = base_family)

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     labels = row.names(mtcars),
                     family = family)

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     base_family = base_family, family = family,
                     id = TRUE)

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     base_family = base_family, family = family,
                     id = TRUE) +
    ggplot2::scale_color_discrete(name = "気筒数",
                                  labels = c("4気筒", "6気筒", "8気筒"))

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     base_family = base_family, family = family,
                     id = TRUE) +
    ggplot2::scale_color_discrete(name = "気筒数",
                                  labels = c("4気筒", "6気筒", "8気筒")) +
    ggplot2::theme(legend.direction = 'horizontal', legend.position = 'top')

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     base_family = base_family, family = family,
                     id = TRUE) +
    ggplot2::theme_bw()

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     family = family,
                     id = TRUE) +
    ggplot2::theme_bw(base_family = base_family)

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     family = family, id = TRUE) +
    ggplot2::scale_color_brewer(palette = "Set1")

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`車重` = wt, `馬力` = hp, `排気量` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     labels = row.names(mtcars),
                     family = family) +
    ggplot2::xlim(-3, 3) 

## ---- echo=FALSE, results='asis'-----------------------------------------
mtcars %>% 
  tibble::rownames_to_column() %>% 
  tibble::rowid_to_column("id") %>% 
  knitr::kable()

