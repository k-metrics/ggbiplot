## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7, fig.height = 5
)

require(tidyverse)

if (Sys.info()[1] == "Windows") {
  windowsFonts(ms_pmin = windowsFont("�l�r �o����"),
               ms_got = windowsFont("�l�r �S�V�b�N"))
  base_family = c("ms_pmin")
  family = c("ms_got")
} else if (Sys.info()[1] == "Linux") {
  base_family = c("Noto Serif CJK JP")
  family = c("Noto Mono")
} else {  # macOS
  base_family = c("HiraKakuPro-W3")
  family = c("Osaka")
}

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`�ԏd` = wt, `�n��` = hp, `�r�C��` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     labels = row.names(mtcars),
                     base_family = base_family)

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`�ԏd` = wt, `�n��` = hp, `�r�C��` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     labels = row.names(mtcars),
                     family = family)

## ------------------------------------------------------------------------
mtcars %>% 
  dplyr::select(`�ԏd` = wt, `�n��` = hp, `�r�C��` = disp, qsec, drat) %>%
  prcomp(scale. = TRUE) %>%
  ggbiplot::ggbiplot(groups = as.factor(mtcars$cyl),
                     id = TRUE,
                     family = family)

## ---- echo=FALSE, results='asis'-----------------------------------------
head(mtcars, 10) %>% 
  # tibble::rowid_to_column("id") %>% 
  knitr::kable()

